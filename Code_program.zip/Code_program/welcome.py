def welcome():
    print("""
    *************************************
    *                                   *
    *           Start Program           *
    *                                   *
    *************************************
    """)
    print('\tBy Muhamamd Rasyid Putera Agung\n\t\t   21524002\n\n')
