data = [
    {'City': 'Jakarta',
     'Kordinat' : '-6.12679500016334, 106.65339560851257'},
    {'City': 'Yogyakarta',
     'Kordinat' : '-7.886251633489997, 110.05960218173766'},
    {'City': 'Bandung',
     'Kordinat' : '-6.616801385020512, 108.14557163828958'},
    {'City': 'Surabaya',
     'Kordinat' : '-7.378619094948739, 112.78727836856608'},
    {'City': 'Bali',
     'Kordinat' : '-8.74476996211164, 115.16560374343673'}
]

data_maskapai = [
{'Maskapai': 'Garuda Indonesia', 'Harga': 1.5 * 106, 'Jenis': 'Boeing 737-800', 'Masa': '10 jam', 'Jangkauan': '6000 km'},
{'Maskapai': 'Lion Air', 'Harga': 1.8 * 106, 'Jenis': 'Boeing 737-900ER', 'Masa': '8 jam', 'Jangkauan': '7500 km'},
{'Maskapai': 'Citilink', 'Harga': 1.2 * 106, 'Jenis': 'Airbus A320', 'Masa': '6 jam', 'Jangkauan': '5000 km'},
{'Maskapai': 'Batik Air', 'Harga': 2.1 * 106, 'Jenis': 'Boeing 737-800', 'Masa': '9 jam', 'Jangkauan': '6000 km'},
{'Maskapai': 'Sriwijaya Air', 'Harga': 1.7 * 10**6, 'Jenis': 'Boeing 737-800', 'Masa': '7 jam', 'Jangkauan': '5500 km'}
]